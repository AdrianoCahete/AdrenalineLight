var meta = document.createElement('meta');
meta.name = 'theme-color';
meta.content = '#3c3c3c';
(document.head||document.documentElement).appendChild(meta);
