/* TODO: Make extension redirect from UOL to new URL */
chrome.runtime.sendMessage({ loadURL: true });